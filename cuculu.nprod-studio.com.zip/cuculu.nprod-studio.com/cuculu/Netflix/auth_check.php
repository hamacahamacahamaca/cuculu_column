<?php
session_start(); // セッションを開始

// セッションがタイムアウトするまでの時間（例: 5分 = 300秒）
$timeout_duration = 300;

// 最後のアクセス時間を確認
if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity']) > $timeout_duration) {
    // 最後のアクセスから5分以上経過 → セッションを削除してログアウト
    session_unset(); // セッションデータを削除
    session_destroy(); // セッションを破棄
    header('Location: /index.php?timeout=1'); // ログインページにリダイレクト
    exit;
}

// 最後のアクティビティ時間を更新（新しい操作があったときにリセット）
$_SESSION['last_activity'] = time();

// ユーザーがログインしていない場合、ログインページにリダイレクト
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header('Location: /index.php'); // ログインページにリダイレクト
    exit;
}
?>