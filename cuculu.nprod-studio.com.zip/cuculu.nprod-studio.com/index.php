<?php
// セッションを開始
session_start();
$message = "";

// フォームが送信された場合の処理
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // ユーザーの入力を取得
    $username = $_POST['username'];
    $password = $_POST['password'];

    // 固定のIDとパスワード
    $fixed_username = "cuculu";
    $fixed_password = "cuculu";

    // 入力されたIDとパスワードをチェック
    if ($username === $fixed_username && $password === $fixed_password) {
        // ログイン成功 → セッションにログイン状態を保存
        $_SESSION['loggedin'] = true;
        header('Location: cuculu'); // cuculuにリダイレクト
        exit;
    } else {
        // ログイン失敗
        $message = "IDまたはパスワードが間違っています。";
    }
}
?>
<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ログインページ</title>
</head>
<body>
    <h1>ログイン</h1>
    <?php if ($message): ?>
        <p style="color: red;"><?php echo htmlspecialchars($message); ?></p>
    <?php endif; ?>
    <form method="POST" action="">
        <label for="username">ID:</label>
        <input type="text" id="username" name="username" required><br>
        <label for="password">パスワード:</label>
        <input type="password" id="password" name="password" required><br>
        <button type="submit">ログイン</button>
    </form>
</body>
</html>